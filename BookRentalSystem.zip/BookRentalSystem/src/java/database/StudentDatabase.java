package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;


import model.Student;
import servlets.RegisterServlet;

public class StudentDatabase {
    
        //to get the list of student ids at admin side
	public List<String> getStudentIds()
	{
		Connection con = DBConnection.getConnection();
		String sql = "select studid from student";
		List<String> ids = new ArrayList<String>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("executed");
			
			while(rs.next())
			{
				ids.add(rs.getString(1));
			}
			
			preparedStatement.close();
		} catch (SQLException e) {			
			System.out.println("Exception" + e);			
		}
		return ids;
	}
	
        //to add students from registration page
	public boolean insert(Student c) 
	{
		System.out.println("insert "+c);
		Connection con = DBConnection.getConnection();
		String sql = "insert into student values(?,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, c.getStudid());
			preparedStatement.setString(2, c.getSname());
			preparedStatement.setString(3, c.getEmail());
			preparedStatement.setString(4, c.getPhone());
			preparedStatement.setString(5, c.getPassword());
			preparedStatement.execute();
			System.out.println("Executed");
			preparedStatement.close();
		} catch (SQLException e) {			
			System.out.println("Exception" + e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
        //at login page to validate student
	public boolean validateStudent(String studid, String password) throws Exception
	{
		System.out.println("validate "+studid);
		Connection con = DBConnection.getConnection();
		String sql = "select password from student where studid=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, studid);
			
			ResultSet rs = preparedStatement.executeQuery();                                               
			if(rs.next())
			{
                            
				if(rs.getString(1).equals(password))
					return true;
				else 
                                    return false;
			}		
			preparedStatement.close();
		} catch (SQLException e) {
			System.out.println("Exception" + e);
			e.printStackTrace();
			return false;
		}
		return false;
	}
}

