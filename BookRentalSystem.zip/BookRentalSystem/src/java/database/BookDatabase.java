package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Book;
import model.RentedBook;
import model.Student;

public class BookDatabase {
        
        //to view all books (rented and available books for rent) at the admin side from "view all books" (called at BookServlet.java) 
	public List<Book> getAllBookst()
	{
		System.out.println("books for rent ");
		Connection con = DBConnection.getConnection();
		String sql = "select * from book";
		List<Book> booksforrent = new ArrayList<Book>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("Executed");
			
			while(rs.next())
			{
				Book b1 = new Book();
				b1.setBookid(rs.getInt(1));
				b1.setType(rs.getString(2));
				b1.setTitle(rs.getString(3));
				b1.setAuthor(rs.getString(4));
				b1.setDescription(rs.getString(5));
				b1.setRentalstatus(rs.getInt(6));
				b1.setImagename(rs.getString(7));
				b1.setStudid(rs.getString(8));
				
				booksforrent.add(b1);
			}
			preparedStatement.close();
			return booksforrent;
		} 
                catch (SQLException e) {
			System.out.println("Exception" + e);			
			return null;
		}

	}

        //to view all available books for rent for student (called at DashboardServlet.java)
	public List<Book> getBookstAvailableForRent()
	{
		System.out.println("books for rent ");
		Connection con = DBConnection.getConnection();
		String sql = "select * from book where rentalstatus=0";
		List<Book> booksforrent = new ArrayList<Book>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);

			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("Executed");

			while(rs.next())
			{
				Book b1 = new Book();
				b1.setBookid(rs.getInt(1));
				b1.setType(rs.getString(2));
				b1.setTitle(rs.getString(3));
				b1.setAuthor(rs.getString(4));
				b1.setDescription(rs.getString(5));
				b1.setImagename(rs.getString(7));
				booksforrent.add(b1);
			}
			preparedStatement.close();
		} 
                catch (SQLException e) {
			System.out.println("Exception" + e);
			return null;
		}
		return booksforrent;
	}
        
        //to view added books by student at student side (StudentAddesBookServlet.java)
	public List<Book> getBooksAddedByStudent(String studid)
	{
		System.out.println("booksadded by student "+studid);
		Connection con = DBConnection.getConnection();
		String sql = "select * from book where studid=?";
		List<Book> booksaddedbystudent = new ArrayList<Book>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);

			preparedStatement.setString(1, studid);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("executed");
			if(rs.next() == false)
			{
				return null;
			}
			else {
				do
				{
					Book b1 = new Book();
					b1.setBookid(rs.getInt(1));
					b1.setType(rs.getString(2));
					b1.setTitle(rs.getString(3));
					b1.setAuthor(rs.getString(4));
					b1.setDescription(rs.getString(5));
					b1.setImagename(rs.getString(7));
					booksaddedbystudent.add(b1);
				}while(rs.next());
			}
			preparedStatement.close();
		} 
                catch (SQLException e) {
			System.out.println("Exception" + e);			
			return null;
		}
		return booksaddedbystudent;
	}
        
        //to view books rented by the student (StudentRentedBookServlet.java)
	public List<RentedBook> getBooksRentedByStudent(String studid)
	{
		System.out.println("books for rent ");
		Connection con = DBConnection.getConnection();
		String sql = "select * from bookrental where studid=?";

		List<RentedBook> rentalbooks = new ArrayList<RentedBook>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);

			preparedStatement.setString(1, studid);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("executed");

			if(rs.next() == false)
			{
				return null;
			}
			else {
				String sql1 = "select * from book where bookid=?";
				do {
					RentedBook b1 = new RentedBook();
					b1.setRentdate(rs.getString(3));
					b1.setDuedate(rs.getString(4));
					b1.setCharge(rs.getDouble(5));
					int bookid = rs.getInt(2);
					PreparedStatement preparedStatement1 = con.prepareStatement(sql1);
					preparedStatement1.setInt(1, bookid);
					ResultSet rs1 = preparedStatement1.executeQuery();
					if(rs1.next())
					{
						Book book = new Book();
						book.setBookid(rs1.getInt(1));
						book.setType(rs1.getString(2));
						book.setTitle(rs1.getString(3));
						book.setAuthor(rs1.getString(4));
						book.setDescription(rs1.getString(5));
						book.setImagename(rs1.getString(7));
						b1.setBook(book);
					}

					rentalbooks.add(b1);
					preparedStatement1.close();
				}while(rs.next());
			}
			preparedStatement.close();                      
		} 
                catch (SQLException e) {
			System.out.println("Exception" + e);			
			return null;
		}
		return rentalbooks;
	}
        
        //to view all books that has been rented at admin side (ViewRentedBookServlet.java)
	public List<RentedBook> getAllBooksRented()
	{
		System.out.println("books for rent ");
		Connection con = DBConnection.getConnection();
		String sql = "select * from bookrental";

		List<RentedBook> rentalbooks = new ArrayList<RentedBook>();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("executed");

			if(rs.next() == false)
			{
				System.out.println("it is false");
				return null;
			}
			else {
				System.out.println("it is true");

				do {
					RentedBook b1 = new RentedBook();
					b1.setRentdate(rs.getString(3));
					b1.setDuedate(rs.getString(4));
					b1.setCharge(rs.getDouble(5));
					int bookid = rs.getInt(2);
					System.out.println(b1);
					String sql1 = "select * from book where bookid=?";
					PreparedStatement preparedStatement1 = con.prepareStatement(sql1);
					preparedStatement1.setInt(1, bookid);
					ResultSet rs1 = preparedStatement1.executeQuery();
					System.out.println("executed for book");
					if(rs1.next())
					{
						System.out.println("book details");
						Book book = new Book();
						book.setBookid(rs1.getInt(1));
						book.setType(rs1.getString(2));
						book.setTitle(rs1.getString(3));
						book.setAuthor(rs1.getString(4));
						book.setDescription(rs1.getString(5));
						book.setImagename(rs1.getString(7));
						book.setStudid(rs1.getString(8));
						b1.setBook(book);
					}

					rentalbooks.add(b1);
					preparedStatement1.close();
				}while(rs.next());
			}

			preparedStatement.close();
		} catch (SQLException e) {
			System.out.println("exception");
			return null;
		}
		return rentalbooks;
	}
        
        //to add books by admin (AddBookServlet.java)
	public boolean insert(Book c) 
	{
		System.out.println("insert "+c);
		Connection con = DBConnection.getConnection();
		String sql = "insert into book(description, title, author, type,imagename,studid, rentalstatus, bookid) values(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, c.getDescription());
			preparedStatement.setString(2, c.getTitle());
			preparedStatement.setString(3, c.getAuthor());
			preparedStatement.setString(4, c.getType());
			preparedStatement.setString(5, c.getImagename());
			preparedStatement.setString(6, c.getStudid());
			preparedStatement.setInt(7, c.getRentalstatus());
                        preparedStatement.setInt(8, c.getBookid());
			preparedStatement.execute();
			System.out.println("Executed");
			preparedStatement.close();
		} catch (SQLException e) {			
			System.out.println("Exception" + e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
        
        //to rent books by the student (RentBookServlet.java) [rent btn]
	public boolean insertBookToRent(RentedBook c, String studid) 
	{
		System.out.println("insert "+c);
		Connection con = DBConnection.getConnection();
		String sql = "insert into bookrental values(?,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, studid);
			preparedStatement.setInt(2, c.getBook().getBookid());
			preparedStatement.setString(3, c.getRentdate());
			preparedStatement.setString(4, c.getDuedate());
			preparedStatement.setDouble(5, c.getCharge());

			preparedStatement.execute();
			String sql1 = "update book set rentalstatus=1 where bookid=?";
			PreparedStatement preparedStatement1 = con.prepareStatement(sql1);
			preparedStatement1.setInt(1, c.getBook().getBookid());
			preparedStatement1.execute();
			System.out.println("Executed update");
			preparedStatement.close();
		} catch (SQLException e) {
			System.out.println("Exception" + e);
			return false;
		}
		return true;
	}
}

