package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Date;

public class RentedBook {

	private Book book;
	private double charge;
	private String duedate;
	private String rentdate;
        private Date date;
        private Object Calender;
        
        public RentedBook() {
            
        }
	
         public RentedBook(Book book, double charge, Date date) {
            super();
            this.book = book;
            this.charge = charge;
            this.date = date;
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            this.rentdate = df.format(this.date);
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DATE, 7);
            this.duedate = df.format(c.getTime());
        }
         
	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public double getCharge() {
		return charge;
	}

	public void setCharge(double charge) {
		this.charge = charge;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public String getRentdate() {
		return rentdate;
	}

	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}
	
	@Override
	public String toString() {
		return "RentedBook [book=" + book + ", charge=" + charge + ", duedate=" + duedate + ", rentdate=" + rentdate
				+ "date=" + date + "]";
	}	

    private DateFormat SimpleDateFormat(String yyyyMMdd) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
