package model;

public class Book {

	private int bookid;
	private String description;
	private String title;
	private String type;
	private String imagename;
	private String author;
	private int rentalstatus;
	private String studid;
	
	public Book() {
            
	}

	public Book( int bookid, String description, String title, String type, String imagename, String author,
			 String studid) {
		super();
                this.bookid = bookid;
		this.description = description;
		this.title = title;
		this.type = type;
		this.imagename = imagename;
		this.author = author;
		this.rentalstatus = 0;
		this.studid = studid;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImagename() {
		return imagename;
	}

	public void setImagename(String imagename) {
		this.imagename = imagename;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getRentalstatus() {
		return rentalstatus;
	}

	public void setRentalstatus(int rentalstatus) {
		this.rentalstatus = rentalstatus;
	}

	public String getStudid() {
		return studid;
	}

	public void setStudid(String studid) {
		this.studid = studid;
	}

	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", description=" + description + ", title=" + title + ", type=" + type
				+ ", imagename=" + imagename + ", author=" + author + ", rentalstatus=" + rentalstatus + ", studid="
				+ studid + "]";
	}
	
}
