package model;

public class Student {

	private String email;
	private String password;
	private String phone;
	private String sname;
	private String studid;
	
        public Student() {
            
        }
	public Student(String email, String password, String phone, String sname, String studid) {
		super();
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.sname = sname;
		this.studid = studid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getStudid() {
		return studid;
	}
	public void setStudid(String studid) {
		this.studid = studid;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Student [email=" + email + ", password=" + password + ", phone=" + phone + ", sname=" + sname
				+ ", studid=" + studid + "]";
	}		
}
