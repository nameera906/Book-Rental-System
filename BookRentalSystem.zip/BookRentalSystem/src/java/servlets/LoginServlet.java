package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.StudentDatabase;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LoginServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String role = request.getParameter("role");
		System.out.println(role);
		if(role.equals("student"))
		{
			String studid = request.getParameter("studid");
			String password = request.getParameter("password");
			StudentDatabase db = new StudentDatabase();
                        try {
                            if(db.validateStudent(studid, password))
			{
				HttpSession session = request.getSession();
				session.setAttribute("id", studid);
				response.sendRedirect("student-dashboard");
			}
			else {
				response.sendRedirect("login.jsp?error=Invalid Credentials");
			}
                        }
                        catch (Exception e)
                        {
                            System.out.println("Exception" + e);
                        }
			
		}
		else {
			String id = request.getParameter("studid");
			String password = request.getParameter("password");
			
			if(id.equals("admin") && password.equals("admin"))
			{
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				response.sendRedirect("admin.jsp");
			}
			else {
				response.sendRedirect("login.jsp?error=Invalid Credentials");
			}
		}		
	}
}
