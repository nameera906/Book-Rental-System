package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.BookDatabase;
import model.Book;
import model.RentedBook;

@WebServlet("/books")
public class BooksServlet extends HttpServlet {
	
    public BooksServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String studid = (String) session.getAttribute("id");
		BookDatabase bdb = new BookDatabase();
		List<Book> books = bdb.getAllBookst();
		System.out.println("books "+books);
		request.setAttribute("books", books);
		RequestDispatcher dispatcher = request.getRequestDispatcher("books.jsp");
		dispatcher.forward(request, response);		
	}
}
