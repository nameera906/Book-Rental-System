package servlets;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.BookDatabase;
import java.util.Date;
import model.Book;
import model.RentedBook;

@WebServlet("/rent")
public class RentBookServlet extends HttpServlet {
	
    public RentBookServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String studid = (String) session.getAttribute("id");
		System.out.println("Rent a book");
		System.out.println(studid);
		int bookid = Integer.parseInt(request.getParameter("id"));
		System.out.println(bookid);
		BookDatabase db = new BookDatabase();
		Book book = new Book();
		book.setBookid(bookid);
                Date d = new Date();
		RentedBook rb = new RentedBook(book, 100, d);
		if(db.insertBookToRent(rb, studid))
			response.sendRedirect("books-rented?msg=success");
		else
		response.sendRedirect("dashboard.jsp?msg=failure");	
	}
}
