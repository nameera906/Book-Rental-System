package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.StudentDatabase;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import model.Student;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	
    public RegisterServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
                String studid = request.getParameter("studid");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String sname = request.getParameter("sname");
		String password = request.getParameter("password");
		
                if(!email.endsWith("student.mes.ac.in"))
                {
                   response.sendRedirect("register.jsp?error=INVALID EMAIL");
                   return;
                }                
		Student s1 = new Student(email, password, phone, sname, studid);
		StudentDatabase db = new StudentDatabase();
		if(db.insert(s1))
			response.sendRedirect("login.jsp");
		else {
			response.sendRedirect("register.jsp");
		}		
	}   
}
