package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDatabase;
import database.StudentDatabase;
import model.Book;

@WebServlet("/addbook")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddBookServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDatabase sdb = new StudentDatabase();
		List<String> ids = sdb.getStudentIds();
		request.setAttribute("ids", ids);
		RequestDispatcher dispatcher = request.getRequestDispatcher("addbook.jsp");
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String description = request.getParameter("description");
		String type = request.getParameter("type");
		String imagename = request.getParameter("imagename");
		String studid = request.getParameter("studid");
                int bookid = Integer.parseInt(request.getParameter("bookid"));
		
		BookDatabase bdb = new BookDatabase();
		Book book = new Book(bookid,description, title, type, imagename, author, studid);
		book.setRentalstatus(0);
		if(bdb.insert(book)) {
			response.sendRedirect("admin.jsp");
		}
		else {
			response.sendRedirect("addbook");
		}
	}	
}
